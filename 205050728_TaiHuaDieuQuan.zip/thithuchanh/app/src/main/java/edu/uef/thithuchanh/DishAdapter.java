package edu.uef.thithuchanh;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.List;

public class DishAdapter extends ArrayAdapter<String> {

    private Context context;
    private List<String> dishes;
    private List<Integer> dishImages;

    public DishAdapter(Context context, List<String> dishes, List<Integer> dishImages) {
        super(context, 0, dishes);
        this.context = context;
        this.dishes = dishes;
        this.dishImages = dishImages;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.dish_item, parent, false);
        }

        String dish = dishes.get(position);
        int dishImage = dishImages.get(position);

        TextView dishNameTextView = convertView.findViewById(R.id.dishNameTextView);
        ImageView dishImageView = convertView.findViewById(R.id.dishImageView);

        dishNameTextView.setText(dish);
        dishImageView.setImageResource(dishImage);

        return convertView;
    }
}